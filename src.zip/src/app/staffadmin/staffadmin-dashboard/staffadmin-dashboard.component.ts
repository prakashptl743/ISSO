import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffadmin-dashboard',
  templateUrl: './staffadmin-dashboard.component.html',
  styleUrls: ['./staffadmin-dashboard.component.css']
})
export class StaffadminDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
