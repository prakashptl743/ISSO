import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-report',
  templateUrl: './test-report.component.html',
  styleUrls: ['./test-report.component.css']
})
export class TestReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
