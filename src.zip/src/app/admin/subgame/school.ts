export class School {
    id:number;
    name:string;
    board:string;
    address:string;
    schoolInfrastructure:string;
    email:string;
    mobile:string;
  }