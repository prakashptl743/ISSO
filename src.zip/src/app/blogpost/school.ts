export class School {
    id: number;
    name: string;
    board: string;


    // 'id' => $cate->schoolId,
    // 'name' => $cate->schoolName,
    // 'board' => $cate->schoolBoard
}
