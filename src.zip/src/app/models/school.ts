export class School {
  //  id: number;
    schoolName: string;
    schoolBoard: string;
    // description: string;
    // image: string;
    // is_featured: boolean;
    // is_active: boolean;
    // created_at: Date;
}
